import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import pandas as pd
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException as wde
import subprocess
import sys
import random
from tbselenium.tbdriver import TorBrowserDriver


def run_browser(type, address, timeout):
    if type == 'chrome':
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        driver = webdriver.Chrome('../driver/chromedriver',
                                  chrome_options=chrome_options)  # Optional argument, if not specified will search path.

        driver.get(address)
        time.sleep(timeout)
        driver.quit()


def b_attack(type, idx, address_lists):
    for i, row in address_lists.iterrows():
        name = row['0']
        address = row['1']
        # state = random.randint(1,10)
        # if state < 6:
        #     print("obf!!!")

        if type == 'chrome':
            url = "file:///home/erc/PycharmProjects/cache_attack/auto_cache_attack/attack_chrome_b.html"
            chrome_options = Options()
            chrome_options.add_argument('--no-sandbox')
            # driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver', chrome_options=chrome_options)
            try:
                driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver',
                                          chrome_options=chrome_options)  # Optional argument, if not specified will search path.
            except wde as e:
                print("\nChrome crashed on launch:")
                print(e)
                print("Trying again in 10 seconds..")
                time.sleep(10)
                driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver', chrome_options=chrome_options)
                print("Success!\n")
            except Exception as e:
                raise Exception(e)
            subprocess.Popen(["./scan_lhp"])
            driver.get(address)
            # button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "clickMe")))
            # input_box = driver.find_element_by_id('address')
            # input_box.send_keys(address)
            # button.click()
            # subprocess.Popen("python3 open_pages.py",shell=True)
            # run_browser(type, "https://www.youtube.com/", timeout)

            time.sleep(21)
            # data = driver.find_element_by_tag_name("body").text
            # line = list(data.split(','))
            # df = pd.DataFrame(line)
            # df.to_csv('/home/erc/PycharmProjects/cache_attack/data/obf_chrome_' + name + '_' + str(idx) + '.csv')
            driver.quit()


def attack(type, idx, address_lists):
    for i, row in address_lists.iterrows():
        name = row['0']
        address = row['1']

        if type == 'chrome':
            url = "file:///home/erc/PycharmProjects/cache_attack/auto_cache_attack/attack_chrome.html"
            chrome_options = Options()
            chrome_options.add_argument('--no-sandbox')
            # driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver', chrome_options=chrome_options)
            try:
                driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver',
                                          options=chrome_options)  # Optional argument, if not specified will search path.
            except wde as e:
                print("\nChrome crashed on launch:")
                print(e)
                print("Trying again in 10 seconds..")
                time.sleep(10)
                driver = webdriver.Chrome('/home/erc/PycharmProjects/cache_attack/driver/chromedriver', chrome_options=chrome_options)
                print("Success!\n")
            except Exception as e:
                raise Exception(e)
            subprocess.Popen(["./scan_lhp"])
            # driver.get(url)
            button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "clickMe")))
            input_box = driver.find_element_by_id('address')
            input_box.send_keys(address)
            button.click()
            # subprocess.Popen("python3 open_pages.py",shell=True)
            # run_browser(type, "https://www.youtube.com/", timeout)

            time.sleep(1)
            data = driver.find_element_by_tag_name("body").text
            line = list(data.split(','))
            df = pd.DataFrame(line)
            df.to_csv('/media/erc/Mistake/linux_chrome/linux_chrome_' + name + '_' + str(idx) + '.csv')
            driver.quit()

        if type == 'firefox':
            url = "file:///home/erc/PycharmProjects/cache_attack/auto_cache_attack/attack_firefox.html"
            try:
                driver = webdriver.Firefox()
            except wde as e:
                print("\nChrome crashed on launch:")
                print(e)
                print("Trying again in 10 seconds..")
                time.sleep(10)
                driver = webdriver.Firefox()
                print("Success!\n")
            except Exception as e:
                raise Exception(e)
            # subprocess.Popen(["./def"])
            driver.execute_script("window.open('" + address + "');")
            driver.get(url)
            button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "clickMe")))
            # time.sleep(5)
            button.click()

            time.sleep(1)

            data = driver.find_element_by_tag_name("body").text
            line = list(data.split(','))
            df = pd.DataFrame(line)
            df.to_csv('/media/erc/Mistake/linux_ff/linux_ff_' + name + '_' + str(idx) + '.csv')
            driver.quit()

        if type == 'tor':
            url = "file:///home/erc/PycharmProjects/cache_attack/auto_cache_attack/attack_tor.html"
            with TorBrowserDriver("/home/erc/Downloads/tor-browser_en-US/") as driver:

                driver.execute_script("window.open('" + address + "');")
                driver.get(url)
                button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "clickMe")))
                button.click()
                time.sleep(1)

                data = driver.find_element_by_tag_name("body").text
                line = list(data.split(','))
                df = pd.DataFrame(line)
                df.to_csv('/media/erc/Mistake/linux_tor/linux_tor_' + name + '_' + str(idx) + '.csv')
                driver.quit()

        print(name + '_' + str(idx) + " finished!")
        time.sleep(1)


if __name__ == '__main__':
    # browser = 'firefox'
    browser = 'chrome'
    # browser = 'tor'
    # browser = sys.argv[1]

    # print(type)
    address_lists = pd.read_csv('/home/erc/PycharmProjects/cache_attack/address_list.csv')
    # address_lists = pd.read_csv('/home/erc/PycharmProjects/cache_attack/test_list.csv')
    # address_lists = address_lists.iloc[:20,:]

    # for i in range(25):
    #     b_attack(browser, i, address_lists)
    for i in range(50,100):
        attack(browser, i, address_lists)

    # attack(type,0,address_lists)

